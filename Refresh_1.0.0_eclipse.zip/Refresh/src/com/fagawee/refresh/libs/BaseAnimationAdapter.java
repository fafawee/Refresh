package com.fagawee.refresh.libs;

public abstract class BaseAnimationAdapter implements AnimationAdapter {

	
	public float getHeaderSpeedRatio()
	{
		return 1;
	}
	public float getFooterSpeedRatio()
	{
		return 1;
	}
}
