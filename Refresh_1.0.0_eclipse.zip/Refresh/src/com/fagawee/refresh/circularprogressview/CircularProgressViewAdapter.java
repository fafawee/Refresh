package com.fagawee.refresh.circularprogressview;


public class CircularProgressViewAdapter implements CircularProgressViewListener {

    @Override
    public void onProgressUpdate(float currentProgress) {

    }

    @Override
    public void onProgressUpdateEnd(float currentProgress) {

    }

    @Override
    public void onAnimationReset() {

    }

    @Override
    public void onModeChanged(boolean isIndeterminate) {

    }
}